import os

files = os.listdir()

#this renumbers the file if there is a missing file in the sequence
for x, file in enumerate(files):
  if file != "renamer.py":
    num = int(file[0:-4])
    #if num > 18:
    while not os.path.exists(f'{x}.png'):
      os.rename(file, f'{x}.png')


elif start_game==True and selection_menu==True:
  screen.fill(const.MENU_BG)
  if wizard_button.draw(screen):
      player='wizard'
  elif elf_button.draw(screen):
      player='elf'
  selection_menu=False
  start_intro=True



       
        '''else:        
            if pause_game == True:
                screen.fill(const.MENU_BG)
                if resume_button.draw(screen):
                    pause_game = False
                if exit_button.draw(screen):
                    run = False
            else:
                
            










start_game = False
    pause_game = False
    start_intro = False

    # define player movement variables
    moving_left = False
    moving_right = False
    moving_up = False
    moving_down = False

    level=1

    # function to reset level
    def reset_level():
        damage_text_group.empty()
        arrow_group.empty()
        item_group.empty()
        fireball_group.empty()

        # create empty tile list
        data = []
        for row in range(const.ROWS):
            r = [-1]*const.COLS
            data.append(r)

        return data
    
    # create empty tile list
    world_data = []
    for row in range(const.ROWS):
        r = [-1]*const.COLS
        world_data.append(r)
    # load in level data and create world
    with open(f"levels/level{level}_data.csv", newline="") as csvfile:
        reader = csv.reader(csvfile, delimiter=",")
        for x, row in enumerate(reader):
            for y, tile in enumerate(row):
                world_data[x][y] = int(tile)

    world = World()
    world.process_data(world_data, tile_list, item_images, mob_animations)

    # create player
    player = world.player
    # create player's weapon
    bow = Weapon(bow_img, arrow_img)

    # extract enemy from world data
    enemy_list = world.character_list

    # create sprite groups
    damage_text_group = pygame.sprite.Group()
    arrow_group = pygame.sprite.Group()
    item_group = pygame.sprite.Group()
    fireball_group = pygame.sprite.Group()

    score_coin = Item(const.SCREEN_WIDTH-115, 23, 0, coin_images, True)
    item_group.add(score_coin)

    # add the items from level data
    for item in world.item_list:
        item_group.add(item)

    # create screen fade
    intro_fade = ScreenFade(1, const.BLACK, 4)
    death_fade = ScreenFade(2, const.PINK, 4)

    run=True
    while run:
        screen.fill(const.BG)
        # control frame rate
        clock.tick(const.FPS)
        
        if player.alive:
            # calculate player movement
            dx = 0
            dy = 0
            #since top left corner of game screen is (0,0) while going down, y coordinate 
            #increases and while going up it decreases because if this wasnt the case 
            #then coordinate will go out of the screen.
            if moving_right:
                dx = const.SPEED
            if moving_left:
                dx = -const.SPEED
            if moving_down:
                dy = const.SPEED
            if moving_up:
                dy = -const.SPEED

            # move player
            screen_scroll, level_complete = player.move(
                dx, dy, world.obstacle_tiles, world.exit_tile)

            # update all objects
            world.update(screen_scroll)
            for enemy in enemy_list:
                fireball = enemy.ai(player, world.obstacle_tiles,
                                    screen_scroll, fireball_img)
                if fireball:
                    fireball_group.add(fireball)
                if enemy.alive:
                    enemy.update()
            player.update()
            arrow = bow.update(player)
            if arrow:
                arrow_group.add(arrow)
                shot_fx.play()
            for arrow in arrow_group:
                damage, damage_pos = arrow.update(
                    screen_scroll, world.obstacle_tiles, enemy_list)
                if damage:  # damage has some value other than 0, damage_pos.y hasnt been centered to keep the damage text above enemys head
                    damage_text = DamageText(
                        damage_pos.centerx, damage_pos.y, str(damage), const.RED)
                    damage_text_group.add(damage_text)
                    hit_fx.play()
            damage_text_group.update()
            fireball_group.update(screen_scroll, player)
            item_group.update(screen_scroll, player, coin_fx, heal_fx)

        # draw player on screen
        world.draw(screen)
        for enemy in enemy_list:
            enemy.draw(screen)
        player.draw(screen)
        bow.draw(screen)
        for arrow in arrow_group:
            arrow.draw(screen)
        for fireball in fireball_group:
            fireball.draw(screen)
        damage_text_group.draw(screen)
        item_group.draw(screen)
        draw_info(player)
        score_coin.draw(screen)

        # check level complete
        if level_complete == True:
            start_intro = True
            level += 1
            world_data = reset_level()
            # load in level data and create world
            with open(f"levels/level{level}_data.csv", newline="") as csvfile:
                reader = csv.reader(csvfile, delimiter=",")
                for x, row in enumerate(reader):
                    for y, tile in enumerate(row):
                        world_data[x][y] = int(tile)
            world = World()
            world.process_data(world_data, tile_list,
                            item_images, mob_animations)
            temp_hp = player.health
            temp_score = player.score
            player = world.player
            player.health = temp_hp
            player.score = temp_score
            enemy_list = world.character_list
            score_coin = Item(const.SCREEN_WIDTH-115,
                            23, 0, coin_images, True)
            item_group.add(score_coin)
            # add the items from level data
            for item in world.item_list:
                item_group.add(item)

        # show intro
        if start_intro == True:
            if intro_fade.fade():
                start_intro = False
                intro_fade.fade_counter = 0

        # show death screen
        if player.alive == False:
            pygame.mixer.music.stop()
            player_ded_fx.play()
            if death_fade.fade():
                player_ded_fx.stop()
                if restart_button.draw(screen):
                    pygame.mixer.music.play(-1, 0.0, 5000)
                    death_fade.fade_counter = 0
                    start_intro = True
                    world_data = reset_level()
                    # load in level data and create world
                    with open(f"levels/level{level}_data.csv", newline="") as csvfile:
                        reader = csv.reader(csvfile, delimiter=",")
                        for x, row in enumerate(reader):
                            for y, tile in enumerate(row):
                                world_data[x][y] = int(tile)
                    world = World()
                    world.process_data(world_data, tile_list,
                                    item_images, mob_animations)
                    player = world.player
                    enemy_list = world.character_list
                    score_coin = Item(const.SCREEN_WIDTH-115,
                                    23, 0, coin_images, True)
                    item_group.add(score_coin)
                    # add the items from level data
                    for item in world.item_list:
                        item_group.add(item)


        # event handler
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            # take keyboard presses
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    moving_left = True
                if event.key == pygame.K_d:
                    moving_right = True
                if event.key == pygame.K_w:
                    moving_up = True
                if event.key == pygame.K_s:
                    moving_down = True
                if event.key == pygame.K_ESCAPE:
                    pause_game = True

            # keyboard buttons released
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_w:
                    moving_up = False
                if event.key == pygame.K_s:
                    moving_down = False

    pygame.display.update()
    pygame.quit()